#!/bin/bash

while IFS= read -r fqdn; do
    echo "Testing $fqdn"
    nc -zv $fqdn 443 
done < fqdn443.txt

